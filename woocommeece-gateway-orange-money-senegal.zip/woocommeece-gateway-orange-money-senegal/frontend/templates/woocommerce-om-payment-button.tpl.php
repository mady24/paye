<?php


		$dateh = date('c');
		$identifiant = md5('2417358923');
		$ref_commande = $control;
		$site = md5('1444586018');
		$total = $amount;
		$commande = $description;
		$algo = "SHA512";
		$cle_secrete = "D9C27929BBABF503D7FED45B625F0A8CA56D25BD3728F7354D282F84144BCD83";
		$cle_bin = pack("H*", $cle_secrete);
		$message = "S2M_COMMANDE=$commande".
		"&S2M_DATEH=$dateh".
		"&S2M_HTYPE=$algo".
		"&S2M_IDENTIFIANT=$identifiant".
		"&S2M_REF_COMMANDE=$ref_commande".
		"&S2M_SITE=$site".
		"&S2M_TOTAL=$total";
		$hmac = strtoupper(hash_hmac(strtolower($algo),$message, $cle_bin));
		//if(isset($_POST))
		//header('Location: http://google.com');
?>

<h3><?php __('Détail de la transaction', 'portail de payement OM') ?></h3>

    <p><?php __('Vous avez choisi de payer par orange money. Cliquer sur le bouton pour continuer', 'portail de payement OM') ?></p>
<form method="POST" action="https://api.paiementorangemoney.com">
    

    <p class="form-submit">
        
        <input type="hidden" name="S2M_IDENTIFIANT" value="<?php echo $identifiant;?>">
          <input type="hidden" name="S2M_SITE" value="<?php echo $site;?>">
          <input type="hidden" name="S2M_TOTAL" value="<?php echo $total;?>">
          <input type="hidden" name="S2M_REF_COMMANDE" value="<?php echo $ref_commande;?>">
          <input type="hidden" name="S2M_COMMANDE" value="<?php echo $commande;?>">
          <input type="hidden" name="S2M_DATEH" value="<?php echo $dateh;?>">
          <input type="hidden" name="S2M_HTYPE" value="<?php echo $algo;?>">
          <input type="hidden" name="S2M_HMAC" value="<?php echo $hmac;?>">
        <input type="hidden" value="<?php echo $return_url; ?>" name="URL">
        <input type="hidden" value="<?php echo $notify_url; ?>" name="URLC">

        <input type="submit" name="submit"  alt="Payer" />
    </p>
</form>
<h3><?php __('Détail de la transaction', 'portail de payement OM') ?></h3>

    <p><?php __('Vous avez choisi de payer par orange money. Cliquer sur le bouton pour continuer', 'portail de payement OM') ?></p>
	<input type="hidden" value="<?php echo $dotpaÒy_id; ?>" name="id">