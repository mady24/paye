<?php
/*
Plugin Name: WooCommerce Gateway Orange Money
Plugin URI: http://michak.pl/woocommerce-gateway-om
Description: Add a credit card payment gateway for Orange Money (Sénégal) to WooCommerce
Version: 1.4
Author: Mady maodo Dieye

Text Domain: om-payment-gateway
*/
if ( ! defined( 'WPINC' ) ) exit; // Exit if accessed directly

require_once dirname(__FILE__) . '/includes/required_plugins.php';

/**
* payment gateway integration for WooCommerce
* @ref http://www.woothemes.com/woocommerce/
*/
function init_woocommerce_gateway_om() {
	define('WOOCOMMERCE_OM_PLUGIN_DIR', plugin_dir_path( __FILE__ ));
	define('WOOCOMMERCE_OM_PLUGIN_URL', plugin_dir_url( __FILE__ ));

	require_once('includes/class.WCGatewayOrangemoney.php');
}

if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	load_plugin_textdomain( 'om-payment-gateway', false, dirname( plugin_basename( __FILE__ ) ) . '/langs/' );
	
	add_action( 'init', 'init_woocommerce_gateway_om' );

	function add_om_class($methods) {
		$methods[] = 'WC_Gateway_Orangemoney';
		return $methods;
	}

	add_filter('woocommerce_payment_gateways', 'add_om_class');	
}