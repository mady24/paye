<?php
	class WC_Gateway_OrangeMoney extends WC_Payment_Gateway {


	    // Gateway name
	    const PAYMENT_METHOD = 'Orange Money';

		/**
		* initialise gateway with custom settings
		*/
		public function __construct() {

			global $woocommerce;

			$this->id = self::PAYMENT_METHOD;
			$this->icon = WOOCOMMERCE_OM_PLUGIN_URL . 'resources/images/index.png';
			$this->has_fields = true;
			$this->title = 'Orange Money';
			$this->description = __('Payement par Kalpé Orange Money', 'portail de payement OM');
			$this->init_form_fields();
			$this->init_settings();
            $this->title = $this->get_option('title');
			//Actions
			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
			add_action( 'woocommerce_receipt_' . $this->id, array( $this, 'receipt_page' ) );
			add_action( 'woocommerce_api_' . strtolower( get_class( $this ) ), array( $this, 'check_om_response_legacy' ) );
		}

		public function init_form_fields() {
			$this->form_fields = array(
				'enabled' => array(
					'title' => __('Enable/Disable', 'woocommerce'),
					'type' => 'checkbox',
					'label' => __('Activer Orange Money', 'portail de payement OM'),
					'default' => 'yes'
				),

				'title' => array(
					'title' => __('Title', 'woocommerce'),
					'type' => 'text',
					'description' => __('This controls the title which user sees during checkout.', 'om-payment-gateway'),
					'default' => 'Orange Money',
					'desc_tip' => true,
				),
				'description' => array(
					'title' => __('Customer Message', 'woocommerce'),
					'type' => 'textarea',
					'default' => '',
                ),
                'identifiant' => array(
                    'title' => __('Identifiant du partenaire (fourni par Orange 10 chiffres)'),
                    'type' => 'input',
                    'default' => ''
                ),
                'site' => array(
                    'title' => __('Identifiant du site marchand (fourni par Orange 10 chiffres)'),
                    'type' => 'input',
                    'default' => ''
                ),
                'cle_secrete' => array(
                    'title' => __('Clé secrete du commerçant'),
                    'type' => 'input',
                    'default' => ''
                )
			);
		}

		function process_payment( $order_id ) {
			global $woocommerce;

			$order = new WC_Order( $order_id );

			$order->reduce_order_stock();

			$woocommerce->cart->empty_cart();

			return array(
				'result' 	=> 'success',
				'redirect'	=> $order->get_checkout_payment_url( true )
			);
		}

		function receipt_page( $order ) {
			//echo '<p>' . __( 'Thank you - your order is now pending payment. You should be automatically redirected to Orange Money to make payment.', 'orange-money-payment-gateway' ) . '</p>';
			echo $this->generate_om_form_legacy( $order );
		}

		function generate_om_form_legacy( $order_id ) {
			$order = new WC_Order( $order_id );


                        $dentifiant = $this->get_option( 'id' );
                        $firstname = $order->billing_first_name;
                        $lastname = $order->billing_last_name;
                        $street = $order->billing_address_1;
                        $street_n1 = $order->billing_address_2;
                        $city = $order->billing_city;
                        $postcode = $order->billing_postcode;
                        $country = $order->billing_country;
                        $email = $order->billing_email;
                        $control = esc_attr( $order_id );
                        $amount = str_replace(',', '.', $order->get_total());
                        $return_url = $this->get_return_url( $order );
                        $notify_url = str_replace( 'https:', 'http:', add_query_arg( 'wc-api', 'WC_Gateway_OM', home_url( '/' )));

                        $payment_type = 0;
                        $description = get_bloginfo('name').': Order id: '.esc_attr( $order_id );
                        $chk = $idetifiant.$amount.$payment_currency.$description.$control.$this->get_option( 'om_pin' );
                        $chk = rawurlencode($chk);
                        if ($this->get_option( 'om_chk' ) == "yes")
                            $signature = hash('md5', $chk);
                        $api_version = "legacy";


	        ob_start();
	            include(WOOCOMMERCE_OM_PLUGIN_DIR . 'frontend/templates/woocommerce-om-payment-button.tpl.php');
	            $html = ob_get_contents();
	        ob_end_clean();

	        return $html;

		}

		function check_om_response_legacy() {
			global $woocommerce;
                        $data = $_POST;
                        $secret_key = "D9C27929BBABF503D7FED45B625F0A8CA56D25BD3728F7354D282F84144BCD83";
                        $bin_key = pack("H*", $secret_key);
                        ksort($data);
                        $message = urldecode(http_build_query($data));
                        $hmac = strtoupper(hash_hmac(strtolower($data['ALGO']), $message, $bin_key));
                        if($hmac === $_POST['HMAC']){
                            echo 'Bingo! Valid Data';
                            switch($data['STATUS']) {
                                case 117:
                                        $order->update_status('failed');
                                        break;
                                case 200:
                                        $order->update_status('on-hold');
                                        break;
                                case 220:
                                        $order->update_status('failed');
                                        break;
                                case 375:
                                        $order->update_status('failed');
                                        break;
                                default:
                                        die('WooCommerce - Wrong status - '.$data['STATUS']);
                        }
                        die('OK');
        
                        
                        }else{
                            die('Souspicious data!');
                        }
                    }    
                }        
